"""Executable SQLite contract tests. Run using Python 3's standard library.
These verify the SQL schema, NOT Flutter rendering or Android integration.
"""
import json
import sqlite3
import tempfile
import unittest
import uuid
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
STATEMENTS=json.loads((ROOT/'assets/db/schema_statements.json').read_text())

def identity(): return str(uuid.uuid4())

class WritingStudioSchemaTest(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(':memory:')
        self.db.execute('PRAGMA foreign_keys = ON')
        for sql in STATEMENTS:
            if not sql.lstrip().startswith('PRAGMA'):
                self.db.execute(sql)
        self.world=identity();self.cont=identity();self.book=identity();self.chapter=identity();self.branch=identity()
        self.db.execute('INSERT INTO universes(id,name) VALUES (?,?)',(self.world,'Stories 🌿'))
        self.db.execute('INSERT INTO continuities(id,universe_id,name) VALUES (?,?,?)',(self.cont,self.world,'Main'))
        self.db.execute('INSERT INTO books(id,universe_id,continuity_id,title) VALUES (?,?,?,?)',(self.book,self.world,self.cont,'Testing the Limits'))
        self.db.execute('INSERT INTO chapters(id,book_id,title,sort_order) VALUES (?,?,?,0)',(self.chapter,self.book,'Chapter 00 / Prologue'))
        self.db.execute('INSERT INTO writing_branches(id,chapter_id,name,is_main) VALUES (?,?,?,1)',(self.branch,self.chapter,'Main Draft'))
        self.db.execute('INSERT INTO branch_workspaces(branch_id) VALUES (?)',(self.branch,))
    def tearDown(self):self.db.close()

    def test_schema_has_core_tables(self):
        names={r[0] for r in self.db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertTrue({'universes','chapters','branch_workspaces','writing_checkpoints','canon_cards','canon_references','entities'}.issubset(names))
        self.assertEqual(self.db.execute('PRAGMA foreign_keys').fetchone()[0],1)

    def test_unicode_save_reopen_and_stale_save_protection(self):
        text="Solene couldn't explain it.\n\n**Liam** listened. 你好 🌿 ‘Hello’."
        rows=self.db.execute('UPDATE branch_workspaces SET markdown=?,revision=revision+1 WHERE branch_id=? AND revision=0',(text,self.branch)).rowcount
        self.assertEqual(rows,1)
        self.assertEqual(self.db.execute('SELECT markdown,revision FROM branch_workspaces').fetchone(),(text,1))
        stale=self.db.execute('UPDATE branch_workspaces SET markdown=?,revision=revision+1 WHERE branch_id=? AND revision=0',('OLD',self.branch)).rowcount
        self.assertEqual(stale,0)
        self.assertEqual(self.db.execute('SELECT markdown FROM branch_workspaces').fetchone()[0],text)

    def _create_checkpoint(self,content='Revision one'):
        cp=identity();self.db.execute('UPDATE branch_workspaces SET markdown=?,revision=revision+1 WHERE branch_id=?',(content,self.branch))
        rev=self.db.execute('SELECT revision FROM branch_workspaces WHERE branch_id=?',(self.branch,)).fetchone()[0]
        self.db.execute('INSERT INTO writing_checkpoints(id,branch_id,chapter_id,title,kind,markdown,revision) VALUES (?,?,?,?,?,?,?)',
                        (cp,self.branch,self.chapter,'First draft','manual',content,rev))
        return cp

    def test_checkpoints_are_immutable(self):
        cp=self._create_checkpoint()
        with self.assertRaisesRegex(sqlite3.IntegrityError,'immutable'):
            self.db.execute('UPDATE writing_checkpoints SET markdown=? WHERE id=?',('MUTATION',cp))
        with self.assertRaisesRegex(sqlite3.IntegrityError,'cannot be deleted'):
            self.db.execute('DELETE FROM writing_checkpoints WHERE id=?',(cp,))
        self.assertEqual(self.db.execute('SELECT markdown FROM writing_checkpoints WHERE id=?',(cp,)).fetchone()[0],'Revision one')

    def test_only_one_main_branch(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute('INSERT INTO writing_branches(id,chapter_id,name,is_main) VALUES (?,?,?,1)',(identity(),self.chapter,'Second Main'))

    def test_canon_reference_and_cross_continuity_block(self):
        card=identity()
        self.db.execute('INSERT INTO canon_cards(id,universe_id,continuity_id,title) VALUES (?,?,?,?)',(card,self.world,self.cont,'Unsent letter'))
        txt='Mira wondered about the letter.'
        self.db.execute('UPDATE branch_workspaces SET markdown=?,revision=1 WHERE branch_id=?',(txt,self.branch))
        self.db.execute('INSERT INTO canon_references(id,card_id,chapter_id,branch_id,role,excerpt,start_offset,end_offset,anchor_revision) VALUES (?,?,?,?,?,?,?,?,?)',
                        (identity(),card,self.chapter,self.branch,'Foreshadowing','letter',24,30,1))
        otherworld,othercont=identity(),identity()
        self.db.execute('INSERT INTO universes(id,name) VALUES (?,?)',(otherworld,'Different universe'))
        self.db.execute('INSERT INTO continuities(id,universe_id,name) VALUES (?,?,?)',(othercont,otherworld,'Main'))
        othercard=identity();self.db.execute('INSERT INTO canon_cards(id,universe_id,continuity_id,title) VALUES (?,?,?,?)',(othercard,otherworld,othercont,'Different canon'))
        with self.assertRaisesRegex(sqlite3.IntegrityError,'continuity'):
            self.db.execute('INSERT INTO canon_references(id,card_id,chapter_id,branch_id,role,excerpt,start_offset,end_offset,anchor_revision) VALUES (?,?,?,?,?,?,?,?,?)',
                            (identity(),othercard,self.chapter,self.branch,'Fact evidence','Mira',0,4,1))

    def test_character_perspective_universe_enforced(self):
        card=identity();self.db.execute('INSERT INTO canon_cards(id,universe_id,continuity_id,title) VALUES (?,?,?,?)',(card,self.world,self.cont,'Cold reputation'))
        person=identity();self.db.execute("INSERT INTO entities(id,universe_id,kind,name) VALUES (?,?,?,?)",(person,self.world,'character','Mira'))
        self.db.execute('INSERT INTO perspective_records(id,card_id,character_id,stance,interpretation) VALUES (?,?,?,?,?)',(identity(),card,person,'Believes','People think she is cold.'))
        otherworld=identity();self.db.execute('INSERT INTO universes(id,name) VALUES (?,?)',(otherworld,'Other'))
        outsider=identity();self.db.execute("INSERT INTO entities(id,universe_id,kind,name) VALUES (?,?,?,?)",(outsider,otherworld,'character','Mira'))
        with self.assertRaisesRegex(sqlite3.IntegrityError,'universe'):
            self.db.execute('INSERT INTO perspective_records(id,card_id,character_id,stance,interpretation) VALUES (?,?,?,?,?)',(identity(),card,outsider,'Suspects','No'))

    def test_checkpoint_tag_universe_enforced(self):
        cp=self._create_checkpoint()
        tag=identity();self.db.execute('INSERT INTO checkpoint_tags(id,universe_id,name) VALUES (?,?,?)',(tag,self.world,'Dialogue'))
        self.db.execute('INSERT INTO checkpoint_tag_links(checkpoint_id,tag_id) VALUES (?,?)',(cp,tag))
        otherworld=identity();self.db.execute('INSERT INTO universes(id,name) VALUES (?,?)',(otherworld,'Elsewhere'))
        otherTag=identity();self.db.execute('INSERT INTO checkpoint_tags(id,universe_id,name) VALUES (?,?,?)',(otherTag,otherworld,'Dialogue'))
        with self.assertRaisesRegex(sqlite3.IntegrityError,'universe mismatch'):
            self.db.execute('INSERT INTO checkpoint_tag_links(checkpoint_id,tag_id) VALUES (?,?)',(cp,otherTag))

    def test_backup_vacuum_integrity(self):
        with tempfile.TemporaryDirectory() as temp:
            location=str(Path(temp)/'test-backup.db').replace("'","''")
            self.db.execute('COMMIT') if self.db.in_transaction else None
            self.db.execute(f"VACUUM INTO '{location}'")
            backup=sqlite3.connect(location)
            try:
                self.assertEqual(backup.execute('PRAGMA integrity_check').fetchone()[0],'ok')
                self.assertEqual(backup.execute('SELECT name FROM universes WHERE id=?',(self.world,)).fetchone()[0],'Stories 🌿')
            finally:backup.close()

    def test_historical_schema_files_do_not_define_current_storage(self):
        self.assertNotIn('chapter_revisions',{x[0] for x in self.db.execute("SELECT name FROM sqlite_master WHERE type='table'")})
        self.assertIn('branch_workspaces',{x[0] for x in self.db.execute("SELECT name FROM sqlite_master WHERE type='table'")})

if __name__=='__main__':unittest.main(verbosity=2)
