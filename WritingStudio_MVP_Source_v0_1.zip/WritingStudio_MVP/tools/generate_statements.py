"""Regenerate schema_statements.json from schema.sql using SQLite's statement parser.
This script needs only Python's standard library.
"""
import json
import sqlite3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sql=(root/'assets/db/schema.sql').read_text()
statements=[]; current=''
for line in sql.splitlines(keepends=True):
    current+=line
    if sqlite3.complete_statement(current):
        if 'CREATE ' in current or 'PRAGMA ' in current:
            statements.append(current.strip())
        current=''
if current.strip():
    raise RuntimeError('Unterminated SQL statement')
(root/'assets/db/schema_statements.json').write_text(json.dumps(statements,indent=2,ensure_ascii=False))
print(f'Generated {len(statements)} SQLite statements')
