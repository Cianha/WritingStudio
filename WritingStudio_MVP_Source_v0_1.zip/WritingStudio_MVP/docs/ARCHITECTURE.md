# Writing Studio — Consolidated Architecture (Implementation Baseline 1.0)

## Product purpose

An Android-first, offline, personal fiction-writing studio for complex, character-driven universes. Product-design requirements derive from the approved Writing Studio planning conversation. The first real-world scenario is Chapter 00 / Prologue of *Testing the Limits*. No original manuscript content is included or generated in the source project.

### Non-negotiable principles

- Write first: writing cannot depend on completing a canon record.
- Writer owns all data: no mandatory login, no network service, no paid AI API.
- Truth, character belief, manuscript revelation, and actually published canon are distinct.
- A chapter can appear in a nonchronological narrative without changing story chronology.
- A fiction continuity is **not** a writing branch.
- Revisions and immutable checkpoint snapshots remain distinct from autosave.
- Canon links are metadata attached to passages; they never alter manuscript prose.
- A card or character may appear across multiple books in the same universe/continuity.
- Provisional design is not equivalent to tested implementation.

## Target and UI

Honor X8a (Honor lists MagicUI 6.1 based on Android 12; actual device upgrades may vary). Android-first Flutter and Dart. Sage, warm-white/paper aesthetics; thumb-friendly touch controls; paper and night themes intended. Editor hides bottom navigation, has a simple Markdown editing view, Read Mode, Focus Mode, checkpoint operations, link actions. A richer hybrid editor remains planned but unverified; no claims of faithful in-place rich formatting.

## Data boundaries

```text
Universe ── Continuity ── Book ── Chapter ── Scene
    ├── Series                ├── Branch ── Working Draft
    │                         │             └── Checkpoints (immutable)
    ├── Character identities  └── Canon reference anchor
    └── Canon Cards ── Fact versions, interpretations, revelations, source refs
```

The actual `assets/db/schema.sql` is **an initial implementation schema, not the complete v1.0 aspirational conceptual schema**. Historic `writing_studio_schema_v1.sql` and `writing_studio_schema_v1_2.sql` were read as prior design references; this is a fresh database contract avoiding the old `chapter_revisions` duplicate revision history. No migration from data in those historic schemas has been implemented.

### Current schema tables

- Library: `universes`, `continuities`, `series`, `books`, `chapters`, `scenes`.
- Writing: `writing_branches`, `branch_workspaces`, `writing_checkpoints`, `checkpoint_tags`, `checkpoint_tag_links`.
- Canon: `entities`, `entity_aliases`, `character_state_versions`, `canon_cards`, `perspective_records`, `timeline_events`, `revelation_events`, `revelation_recipients`, `canon_references`, `motifs`, `motif_appearances`.
- Editorial: `editorial_notes`.
- Utilities: `app_settings`.

### Boundaries and guarantees

- All mutable draft writes are guarded by a revision compare-and-swap.
- Checkpoint content has SQL immutability triggers, including a no-delete rule.
- Branches are chapter-local. Exactly one main branch is permitted for a chapter.
- Cards are continuity-specific within a universe.
- A cross-continuity passage link raises an SQL error.
- A viewpoint character and canon card in different universes cannot be linked as a perspective record.
- Checkpoint tags cannot cross universes.
- Canon anchors preserve excerpt, UTF-16 source offsets, adjoining text, link role, branch and checkpoint identity. Direct offsets are checked on every save. A uniquely re-found excerpt is relocated; deleted or ambiguous excerpts are flagged for review. **More comprehensive diff-aware anchoring remains future work.**
- Working draft text is Markdown. Manuscript export does not include SQLite metadata or private cards.
- The app does not automatically derive character knowledge from chronological chapter order.

## Planned but not yet fully implemented

1. **Rich in-place hybrid formatting.** Existing source editor exposes Markdown markers, selected-text shortcuts, and a rendered Markdown reading mode. Super Editor/Fleather evaluation awaits the Flutter SDK and Android runtime.
2. **Branch creation, switching, and merges.** The tables distinguish branches, but only main draft is exposed in this source UI.
3. **Full canon knowledge graph.** Storage skeleton exists, but editing perspectives, multiple disclosure recipients, story-time uncertainty, published reader-state projection, card-to-card relations, and changing character traits across time require more services and UI.
4. **Visual maps.** Character relationships, revelations, motifs and callback map.
5. **Editorial notes.** Basic schema only, dedicated editor UI pending.
6. **Approval/release/publication.** Requires immutable approval pointers and release projections, deferred from the first writing milestone.
7. **SQLite FTS5.** Current search uses a case-insensitive `LIKE` fallback. FTS5 availability on the Honor OS/runtime must be established before enabling it.
8. **Complex comparison.** Current checkpoint comparison displays previous/current texts, not a word-level structural diff.
9. **True historical migration.** This is database schema v1; future changes must use explicit numbered migrations and backup tests.
10. **User-tunable appearance preferences** beyond live font adjustment; persistence of preferences deferred.
11. **EPUB/PDF and AI context packages** are future functions and must keep private author data separate.

## Editing and persistence contract

1. The editor maintains current in-memory text.
2. Debounced save after ~650 ms inactivity, with best-effort flush on navigation and app lifecycle changes.
3. `UPDATE branch_workspaces ... WHERE revision = expectedRevision` stops stale writes.
4. A pending autosave operation is serialized, with retry on more edits.
5. Checkpoint creation first flushes working draft, then transactionally snapshots it.
6. Restore first snapshots the prior draft, then updates working draft in one DB transaction.
7. On save failures, the screen does not intentionally discard current in-memory text and it provides a retry action. **Abrupt process termination during a pending failed save can still lose unsaved text.**
8. Copying a backup uses SQLite `VACUUM INTO`; the generated file is checked by integrity validation. Restore validates a picked backup, makes a safety database copy, closes the open connection, and swaps files. This needs Android runtime testing before it may be called robust production recovery.
9. No private canon or internal links are inserted into Markdown exports.

## User journey

1. Open app → create fictional universe → default Main continuity.
2. Add *Testing the Limits* as a book.
3. Add “Chapter 00 — Prologue”.
4. Type and use Bold/Italic/Scene Break toolbar while in Markdown-first editor.
5. Wait for saved indicator; back navigation flushes pending edits.
6. Make a named checkpoint; inspect history; restore with safety copy if desired.
7. Highlight an exact passage, tap Canon, choose existing card or create new; attach relationship role.
8. Open references list, inspect anchor validity.
9. Export the chapter as Markdown or plain text using the Android share sheet.
10. Back up entire local library from Tools; independently save the .db outside app private storage.
11. Restore from a .db backup with explicit confirmation and restart to refresh screens (runtime unverified).

## Build strategy

The source project intentionally omits auto-generated Android platform runner scaffolding because no Flutter SDK is installed in the current execution container. The GitHub Actions workflow first invokes `flutter create --platforms=android --project-name writing_studio .`, then runs analysis, Flutter tests, and a **debug** APK build. It is a proposed build workflow and HAS NOT been run here.

The first deliverable to claim as a working APK must be the actual compiled `.apk`, checked for structural validity, installed on a compatible Android emulator or device where possible, and tested against writing/persistence/links/export/backups.

## Testing status

- SQL schema constraints, stale-save semantics, backup snapshot integrity: verified by Python's `sqlite3` test suite.
- Flutter compilation, widget tests, package resolution, Android installability, keyboard selection, Markdown rendering, share-sheet integration, backup restore on-device: **not run** because SDK/toolchain and terminal internet access are unavailable.
- Do not imply the existence of an APK until compilation succeeds.
