-- Writing Studio self-contained initial schema, version 1.
-- Replaces two historical concept-stage scripts for NEW databases; not a migration of existing user data.
PRAGMA foreign_keys = ON;
CREATE TABLE universes (
 id TEXT PRIMARY KEY, name TEXT NOT NULL CHECK(length(trim(name))>0), description TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE continuities (
 id TEXT PRIMARY KEY, universe_id TEXT NOT NULL REFERENCES universes(id) ON DELETE RESTRICT,
 name TEXT NOT NULL CHECK(length(trim(name))>0),
 UNIQUE(id,universe_id), UNIQUE(universe_id,name)
);
CREATE TABLE series (
 id TEXT PRIMARY KEY, universe_id TEXT NOT NULL REFERENCES universes(id) ON DELETE RESTRICT,
 title TEXT NOT NULL CHECK(length(trim(title))>0), UNIQUE(id,universe_id)
);
CREATE TABLE books (
 id TEXT PRIMARY KEY, universe_id TEXT NOT NULL, continuity_id TEXT NOT NULL,
 series_id TEXT, title TEXT NOT NULL CHECK(length(trim(title))>0), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(continuity_id,universe_id) REFERENCES continuities(id,universe_id),
 FOREIGN KEY(series_id,universe_id) REFERENCES series(id,universe_id), UNIQUE(id,universe_id)
);
CREATE TABLE chapters (
 id TEXT PRIMARY KEY, book_id TEXT NOT NULL REFERENCES books(id) ON DELETE RESTRICT,
 title TEXT NOT NULL, sort_order INTEGER NOT NULL CHECK(sort_order>=0),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(book_id,sort_order), UNIQUE(id,book_id)
);
CREATE TABLE scenes (
 id TEXT PRIMARY KEY, chapter_id TEXT NOT NULL REFERENCES chapters(id) ON DELETE RESTRICT,
 title TEXT, narrative_order REAL, story_position TEXT
);
CREATE TABLE writing_branches (
 id TEXT PRIMARY KEY, chapter_id TEXT NOT NULL REFERENCES chapters(id) ON DELETE RESTRICT,
 name TEXT NOT NULL COLLATE NOCASE CHECK(length(trim(name))>0), is_main INTEGER NOT NULL DEFAULT 0 CHECK(is_main IN(0,1)),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(id,chapter_id), UNIQUE(chapter_id,name)
);
CREATE UNIQUE INDEX idx_main_branch ON writing_branches(chapter_id) WHERE is_main=1;
CREATE TABLE branch_workspaces (
 branch_id TEXT PRIMARY KEY REFERENCES writing_branches(id) ON DELETE RESTRICT,
 markdown TEXT NOT NULL DEFAULT '', revision INTEGER NOT NULL DEFAULT 0 CHECK(revision>=0),
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE writing_checkpoints (
 id TEXT PRIMARY KEY, branch_id TEXT NOT NULL, chapter_id TEXT NOT NULL,
 title TEXT NOT NULL CHECK(length(trim(title))>0), description TEXT NOT NULL DEFAULT '',
 kind TEXT NOT NULL CHECK(kind IN ('manual','pre_restore','automatic')),
 markdown TEXT NOT NULL, revision INTEGER NOT NULL CHECK(revision>=0),
 parent_id TEXT REFERENCES writing_checkpoints(id) ON DELETE RESTRICT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(branch_id,chapter_id) REFERENCES writing_branches(id,chapter_id)
);
CREATE TRIGGER immutable_checkpoint_change BEFORE UPDATE OF markdown,revision,branch_id,chapter_id,parent_id,created_at ON writing_checkpoints
BEGIN SELECT RAISE(ABORT,'checkpoint content is immutable'); END;
CREATE TRIGGER immutable_checkpoint_delete BEFORE DELETE ON writing_checkpoints
BEGIN SELECT RAISE(ABORT,'checkpoint cannot be deleted'); END;
CREATE TABLE checkpoint_tags (
 id TEXT PRIMARY KEY, universe_id TEXT NOT NULL REFERENCES universes(id) ON DELETE RESTRICT,
 name TEXT NOT NULL COLLATE NOCASE, color TEXT NOT NULL DEFAULT '#81929C', UNIQUE(universe_id,name)
);
CREATE TABLE checkpoint_tag_links (
 checkpoint_id TEXT NOT NULL REFERENCES writing_checkpoints(id) ON DELETE RESTRICT,
 tag_id TEXT NOT NULL REFERENCES checkpoint_tags(id) ON DELETE RESTRICT,
 PRIMARY KEY(checkpoint_id,tag_id)
);
CREATE TRIGGER ensure_tag_universe BEFORE INSERT ON checkpoint_tag_links
BEGIN
 SELECT RAISE(ABORT,'checkpoint tag universe mismatch')
 WHERE (SELECT b.universe_id FROM writing_checkpoints p JOIN chapters c ON p.chapter_id=c.id JOIN books b ON b.id=c.book_id WHERE p.id=NEW.checkpoint_id)
 <> (SELECT universe_id FROM checkpoint_tags WHERE id=NEW.tag_id);
END;
CREATE TABLE entities (
 id TEXT PRIMARY KEY, universe_id TEXT NOT NULL REFERENCES universes(id) ON DELETE RESTRICT,
 kind TEXT NOT NULL CHECK(kind IN('character','location','organization','object')),
 name TEXT NOT NULL CHECK(length(trim(name))>0), overview TEXT NOT NULL DEFAULT '',
 UNIQUE(id,universe_id)
);
CREATE TABLE entity_aliases (
 id TEXT PRIMARY KEY, entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE RESTRICT, alias TEXT NOT NULL
);
CREATE TABLE character_state_versions (
 id TEXT PRIMARY KEY, entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE RESTRICT,
 continuity_id TEXT NOT NULL REFERENCES continuities(id) ON DELETE RESTRICT,
 timeline_position TEXT, attribute TEXT NOT NULL, value TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'author_note'
);
CREATE TABLE canon_cards (
 id TEXT PRIMARY KEY, universe_id TEXT NOT NULL REFERENCES universes(id) ON DELETE RESTRICT,
 continuity_id TEXT NOT NULL, title TEXT NOT NULL CHECK(length(trim(title))>0),
 kind TEXT NOT NULL DEFAULT 'fact', certainty TEXT NOT NULL DEFAULT 'undecided',
 author_truth TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(id,continuity_id),
 FOREIGN KEY(continuity_id,universe_id) REFERENCES continuities(id,universe_id)
);
CREATE TABLE perspective_records (
 id TEXT PRIMARY KEY, card_id TEXT NOT NULL REFERENCES canon_cards(id) ON DELETE RESTRICT,
 character_id TEXT NOT NULL REFERENCES entities(id) ON DELETE RESTRICT,
 stance TEXT NOT NULL, interpretation TEXT NOT NULL, story_position TEXT,
 recorded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE timeline_events (
 id TEXT PRIMARY KEY, continuity_id TEXT NOT NULL REFERENCES continuities(id) ON DELETE RESTRICT,
 title TEXT NOT NULL, story_position TEXT, order_hint REAL
);
CREATE TABLE revelation_events (
 id TEXT PRIMARY KEY, card_id TEXT NOT NULL REFERENCES canon_cards(id) ON DELETE RESTRICT,
 scene_id TEXT REFERENCES scenes(id) ON DELETE RESTRICT, narrator_id TEXT REFERENCES entities(id) ON DELETE RESTRICT,
 detail TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'disclosure', publication_status TEXT NOT NULL DEFAULT 'planned'
);
CREATE TABLE revelation_recipients (
 revelation_id TEXT NOT NULL REFERENCES revelation_events(id) ON DELETE RESTRICT,
 character_id TEXT NOT NULL REFERENCES entities(id) ON DELETE RESTRICT,
 new_interpretation TEXT NOT NULL DEFAULT '', PRIMARY KEY(revelation_id,character_id)
);
CREATE TABLE canon_references (
 id TEXT PRIMARY KEY, card_id TEXT NOT NULL REFERENCES canon_cards(id) ON DELETE RESTRICT,
 chapter_id TEXT NOT NULL REFERENCES chapters(id) ON DELETE RESTRICT,
 branch_id TEXT NOT NULL REFERENCES writing_branches(id) ON DELETE RESTRICT,
 checkpoint_id TEXT REFERENCES writing_checkpoints(id) ON DELETE RESTRICT,
 scene_id TEXT REFERENCES scenes(id) ON DELETE RESTRICT,
 role TEXT NOT NULL CHECK(length(trim(role))>0),
 excerpt TEXT NOT NULL CHECK(length(excerpt)>0),
 before_context TEXT NOT NULL DEFAULT '', after_context TEXT NOT NULL DEFAULT '',
 start_offset INTEGER NOT NULL CHECK(start_offset>=0), end_offset INTEGER NOT NULL CHECK(end_offset>=start_offset),
 anchor_revision INTEGER NOT NULL CHECK(anchor_revision>=0),
 anchor_state TEXT NOT NULL DEFAULT 'valid' CHECK(anchor_state IN('valid','relocated','needs_review')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(branch_id,chapter_id) REFERENCES writing_branches(id,chapter_id)
);
CREATE TABLE motifs (
 id TEXT PRIMARY KEY, universe_id TEXT NOT NULL REFERENCES universes(id) ON DELETE RESTRICT,
 name TEXT NOT NULL, description TEXT NOT NULL DEFAULT ''
);
CREATE TABLE motif_appearances (
 id TEXT PRIMARY KEY, motif_id TEXT NOT NULL REFERENCES motifs(id) ON DELETE RESTRICT,
 canon_reference_id TEXT NOT NULL REFERENCES canon_references(id) ON DELETE RESTRICT,
 meaning TEXT NOT NULL DEFAULT ''
);
CREATE TABLE editorial_notes (
 id TEXT PRIMARY KEY, universe_id TEXT NOT NULL REFERENCES universes(id) ON DELETE RESTRICT,
 subject_kind TEXT NOT NULL, subject_id TEXT NOT NULL,
 checkpoint_id TEXT REFERENCES writing_checkpoints(id) ON DELETE RESTRICT,
 body TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE INDEX idx_chapters_book ON chapters(book_id,sort_order);
CREATE INDEX idx_cp_branch ON writing_checkpoints(branch_id,created_at);
CREATE INDEX idx_refs_chapter ON canon_references(chapter_id);
CREATE INDEX idx_refs_card ON canon_references(card_id);
CREATE INDEX idx_perspective_card ON perspective_records(card_id);

-- Cross-table canon constraints protect data even if a UI bug bypasses application checks.
CREATE TRIGGER ensure_reference_context BEFORE INSERT ON canon_references BEGIN
 SELECT RAISE(ABORT,'canon reference crosses continuity')
 WHERE (SELECT c.continuity_id FROM canon_cards c WHERE c.id=NEW.card_id)
 <> (SELECT b.continuity_id FROM chapters ch JOIN books b ON ch.book_id=b.id WHERE ch.id=NEW.chapter_id);
 SELECT RAISE(ABORT,'canon reference branch mismatch')
 WHERE (SELECT chapter_id FROM writing_branches WHERE id=NEW.branch_id)<>NEW.chapter_id;
 SELECT RAISE(ABORT,'canon reference checkpoint mismatch')
 WHERE NEW.checkpoint_id IS NOT NULL AND
 ((SELECT branch_id FROM writing_checkpoints WHERE id=NEW.checkpoint_id)<>NEW.branch_id
 OR (SELECT chapter_id FROM writing_checkpoints WHERE id=NEW.checkpoint_id)<>NEW.chapter_id);
END;
CREATE TRIGGER ensure_perspective_context BEFORE INSERT ON perspective_records BEGIN
 SELECT RAISE(ABORT,'perspective character universe mismatch')
 WHERE (SELECT universe_id FROM entities WHERE id=NEW.character_id)
 <> (SELECT universe_id FROM canon_cards WHERE id=NEW.card_id);
END;
CREATE TRIGGER ensure_character_state_context BEFORE INSERT ON character_state_versions BEGIN
 SELECT RAISE(ABORT,'character state crosses universe')
 WHERE (SELECT universe_id FROM entities WHERE id=NEW.entity_id)
 <> (SELECT universe_id FROM continuities WHERE id=NEW.continuity_id);
END;
