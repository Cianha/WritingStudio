import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'data/studio_repository.dart';
import 'ui/library_page.dart';
import 'ui/canon_page.dart';
import 'ui/tools_page.dart';

final studioProvider = Provider<StudioRepository>((ref) => StudioRepository());

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ProviderScope(child: WritingStudioApp()));
}

const sage = Color(0xFF647D69);
const paper = Color(0xFFF6F3EB);

class WritingStudioApp extends StatelessWidget {
  const WritingStudioApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Writing Studio',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor:sage, brightness:Brightness.light),
        scaffoldBackgroundColor: paper,
        appBarTheme: const AppBarTheme(backgroundColor:paper),
        cardTheme: CardThemeData(color:Colors.white, elevation:0, shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18))),
        inputDecorationTheme: InputDecorationTheme(border:OutlineInputBorder(borderRadius:BorderRadius.circular(12))),
      ),
      home: const StudioHome(),
    );
  }
}

class StudioHome extends StatefulWidget {
  const StudioHome({super.key});
  @override
  State<StudioHome> createState() => _StudioHomeState();
}

class _StudioHomeState extends State<StudioHome> {
  int index = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index:index,children:const [LibraryPage(), CanonPage(), ToolsPage()]),
      bottomNavigationBar: NavigationBar(
        selectedIndex:index,
        onDestinationSelected:(v)=>setState(()=>index=v),
        destinations:const [
          NavigationDestination(icon:Icon(Icons.auto_stories_outlined),selectedIcon:Icon(Icons.auto_stories),label:'Library'),
          NavigationDestination(icon:Icon(Icons.hub_outlined),selectedIcon:Icon(Icons.hub),label:'Canon'),
          NavigationDestination(icon:Icon(Icons.tune),label:'Tools'),
        ],
      ),
    );
  }
}

Future<String?> askForText(BuildContext context, String heading, {String hint='',String initial=''}) async {
  final controller = TextEditingController(text:initial);
  final result = await showDialog<String>(
    context:context,
    builder:(dialogContext)=>AlertDialog(
      title:Text(heading),
      content:TextField(controller:controller, autofocus:true, textCapitalization:TextCapitalization.sentences,
        decoration:InputDecoration(hintText:hint), onSubmitted:(v){if(v.trim().isNotEmpty)Navigator.pop(dialogContext,v.trim());}),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(dialogContext),child:const Text('Cancel')),
        FilledButton(onPressed:()=>Navigator.pop(dialogContext,controller.text.trim().isEmpty?null:controller.text.trim()),child:const Text('Save')),
      ],
    ),
  );
  controller.dispose();
  return result;
}

void reportError(BuildContext context,Object error) {
  if (!context.mounted) return;
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(error.toString()),behavior:SnackBarBehavior.floating));
}
