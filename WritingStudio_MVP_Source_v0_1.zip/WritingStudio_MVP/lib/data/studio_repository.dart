import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

final class SaveConflict implements Exception {
  const SaveConflict();
  @override
  String toString() => 'Another revision was saved; your unsaved text is still held in the editor.';
}

class StudioRepository {
  static const databaseName = 'writing_studio.sqlite';
  final _ids = const Uuid();
  Database? _database;
  String id() => _ids.v4();

  Future<Database> get db async {
    if (_database != null && _database!.isOpen) return _database!;
    final path = p.join(await getDatabasesPath(), databaseName);
    _database = await openDatabase(
      path,
      version: 1,
      onConfigure: (d) async => d.execute('PRAGMA foreign_keys = ON'),
      onCreate: (d, version) async {
        final raw = await rootBundle.loadString('assets/db/schema_statements.json');
        for (final statement in (jsonDecode(raw) as List).cast<String>()) {
          if (!statement.trimLeft().startsWith('PRAGMA')) await d.execute(statement);
        }
      },
    );
    return _database!;
  }

  Future<void> close() async {
    await _database?.close();
    _database = null;
  }

  Future<List<Map<String, Object?>>> universes() async =>
      (await (await db).query('universes', orderBy: 'created_at DESC')).toList();

  Future<List<Map<String, Object?>>> books(String universeId) async =>
      (await (await db).query('books', where: 'universe_id=?', whereArgs: [universeId], orderBy: 'created_at DESC')).toList();

  Future<List<Map<String, Object?>>> chapters(String bookId) async =>
      (await (await db).query('chapters', where: 'book_id=?', whereArgs: [bookId], orderBy: 'sort_order ASC')).toList();

  Future<String> createUniverse(String name) async {
    final uid = id(), cid = id();
    await (await db).transaction((tx) async {
      await tx.insert('universes', {'id': uid, 'name': name.trim()});
      await tx.insert('continuities', {'id': cid, 'universe_id': uid, 'name': 'Main'});
    });
    return uid;
  }

  Future<String> createBook(String universeId, String title) async {
    final database = await db;
    final cont = await database.query('continuities', columns: ['id'], where: 'universe_id=?', whereArgs: [universeId], limit: 1);
    if (cont.isEmpty) throw StateError('Universe has no continuity');
    final bookId = id();
    await database.insert('books', {'id': bookId, 'universe_id': universeId, 'continuity_id': cont.first['id'], 'title': title.trim()});
    return bookId;
  }

  Future<String> createChapter(String bookId, String title) async {
    final chapterId = id(), branchId = id();
    await (await db).transaction((tx) async {
      final result = await tx.rawQuery('SELECT COALESCE(MAX(sort_order),-1)+1 AS pos FROM chapters WHERE book_id=?', [bookId]);
      await tx.insert('chapters', {'id': chapterId, 'book_id': bookId, 'title': title.trim(), 'sort_order': result.first['pos']});
      await tx.insert('writing_branches', {'id': branchId, 'chapter_id': chapterId, 'name': 'Main Draft', 'is_main': 1});
      await tx.insert('branch_workspaces', {'branch_id': branchId, 'markdown': '', 'revision': 0});
    });
    return chapterId;
  }

  Future<Map<String, Object?>> mainDraft(String chapterId) async {
    final rows = await (await db).rawQuery('''
      SELECT w.branch_id, w.markdown, w.revision, w.updated_at FROM branch_workspaces w
      JOIN writing_branches b ON b.id = w.branch_id
      WHERE b.chapter_id=? AND b.is_main=1 LIMIT 1
    ''', [chapterId]);
    if (rows.isEmpty) throw StateError('Chapter has no main draft');
    return rows.first;
  }

  // Optimistic concurrency: a delayed write can never replace a newer revision.
  Future<int> saveDraft(String branchId, int expectedRevision, String markdown) async {
    final database = await db;
    final next = expectedRevision + 1;
    final n = await database.rawUpdate('''
      UPDATE branch_workspaces SET markdown=?, revision=?, updated_at=CURRENT_TIMESTAMP
      WHERE branch_id=? AND revision=?
    ''', [markdown, next, branchId, expectedRevision]);
    if (n != 1) throw const SaveConflict();
    await repairAnchors(branchId, markdown, next);
    return next;
  }

  Future<void> repairAnchors(String branchId, String currentText, int revision) async {
    final database = await db;
    final rows = await database.query('canon_references', where: 'branch_id=? AND checkpoint_id IS NULL', whereArgs: [branchId]);
    await database.transaction((tx) async {
      for (final row in rows) {
        final target = row['excerpt'] as String;
        final from = row['start_offset'] as int;
        final to = row['end_offset'] as int;
        if (from <= currentText.length && to <= currentText.length && currentText.substring(from, to) == target) {
          await tx.update('canon_references', {'anchor_state': 'valid', 'anchor_revision': revision}, where: 'id=?', whereArgs: [row['id']]);
          continue;
        }
        final first = currentText.indexOf(target);
        final last = currentText.lastIndexOf(target);
        if (first >= 0 && first == last) {
          // Unique exact text can be relocated conservatively; duplicates must be reviewed.
          await tx.update('canon_references', {
            'start_offset': first, 'end_offset': first + target.length,
            'anchor_state': 'relocated', 'anchor_revision': revision
          }, where: 'id=?', whereArgs: [row['id']]);
        } else {
          await tx.update('canon_references', {'anchor_state': 'needs_review', 'anchor_revision': revision}, where: 'id=?', whereArgs: [row['id']]);
        }
      }
    });
  }

  Future<List<Map<String, Object?>>> checkpoints(String branchId) async =>
      (await (await db).query('writing_checkpoints', where: 'branch_id=?', whereArgs: [branchId], orderBy: 'created_at DESC')).toList();

  Future<String> createCheckpoint(String chapterId, String branchId, String title, {String kind = 'manual', String description = ''}) async {
    return (await db).transaction((tx) async {
      final rows = await tx.query('branch_workspaces', where: 'branch_id=?', whereArgs: [branchId]);
      if (rows.isEmpty) throw StateError('Missing draft');
      final w = rows.first;
      final previous = await tx.query('writing_checkpoints', where: 'branch_id=?', whereArgs: [branchId], orderBy: 'created_at DESC, rowid DESC', limit: 1);
      if (previous.isNotEmpty && previous.first['markdown'] == w['markdown'] && kind == 'automatic') {
        return previous.first['id'] as String;
      }
      final checkpointId = id();
      await tx.insert('writing_checkpoints', {
        'id': checkpointId, 'branch_id': branchId, 'chapter_id': chapterId,
        'title': title.trim(), 'description': description, 'kind': kind,
        'markdown': w['markdown'], 'revision': w['revision'],
        'parent_id': previous.isEmpty ? null : previous.first['id'],
      });
      return checkpointId;
    });
  }

  Future<void> restoreCheckpoint(String checkpointId) async {
    final database = await db;
    await database.transaction((tx) async {
      final cps = await tx.query('writing_checkpoints', where: 'id=?', whereArgs: [checkpointId]);
      if (cps.isEmpty) throw StateError('Unknown checkpoint');
      final cp = cps.first;
      final branchId = cp['branch_id'] as String;
      final chapterId = cp['chapter_id'] as String;
      final working = (await tx.query('branch_workspaces', where: 'branch_id=?', whereArgs: [branchId])).first;
      final existing = working['markdown'] as String;
      if (existing == cp['markdown']) return;
      final currentHead = await tx.query('writing_checkpoints', where: 'branch_id=?', whereArgs: [branchId], orderBy: 'created_at DESC, rowid DESC', limit: 1);
      await tx.insert('writing_checkpoints', {
        'id': id(), 'branch_id': branchId, 'chapter_id': chapterId,
        'title': 'Safety copy before restore', 'kind': 'pre_restore',
        'markdown': existing, 'revision': working['revision'],
        'parent_id': currentHead.isEmpty ? null : currentHead.first['id'],
      });
      await tx.update('branch_workspaces', {'markdown': cp['markdown'], 'revision': (working['revision'] as int) + 1, 'updated_at': DateTime.now().toUtc().toIso8601String()}, where: 'branch_id=?', whereArgs: [branchId]);
    });
    final cp = (await database.query('writing_checkpoints', where: 'id=?', whereArgs: [checkpointId])).first;
    final working = await mainDraft(cp['chapter_id'] as String);
    await repairAnchors(cp['branch_id'] as String, working['markdown'] as String, working['revision'] as int);
  }

  Future<List<Map<String, Object?>>> canonCards(String universeId) async =>
      (await (await db).query('canon_cards', where: 'universe_id=?', whereArgs: [universeId], orderBy: 'title COLLATE NOCASE')).toList();

  Future<String> createCard(String universeId, String title, {String authorTruth = ''}) async {
    final database = await db;
    final c = await database.query('continuities', columns: ['id'], where: 'universe_id=?', whereArgs: [universeId], limit: 1);
    if (c.isEmpty) throw StateError('Missing continuity');
    final cardId = id();
    await database.insert('canon_cards', {'id':cardId,'universe_id':universeId,'continuity_id':c.first['id'],'title':title.trim(),'author_truth':authorTruth});
    return cardId;
  }

  Future<void> linkSelection({required String cardId, required String chapterId, required String branchId,
    required int revision, required String markdown, required int start, required int end, required String role}) async {
    if (start < 0 || end > markdown.length || end <= start) throw ArgumentError('Select passage text first.');
    final excerpt = markdown.substring(start, end);
    final database = await db;
    final check = await database.rawQuery('''
      SELECT 1 FROM canon_cards ca JOIN books b ON b.continuity_id=ca.continuity_id
      JOIN chapters ch ON ch.book_id=b.id
      JOIN writing_branches br ON br.chapter_id=ch.id
      WHERE ca.id=? AND ch.id=? AND br.id=?
    ''', [cardId, chapterId, branchId]);
    if (check.isEmpty) throw StateError('Canon card and chapter belong to different continuities.');
    await database.insert('canon_references', {
      'id': id(), 'card_id':cardId,'chapter_id':chapterId,'branch_id':branchId,
      'role':role,'excerpt':excerpt,
      'before_context':markdown.substring(start >= 50 ? start-50 : 0,start),
      'after_context':markdown.substring(end,(end+50<=markdown.length) ? end+50 : markdown.length),
      'start_offset':start,'end_offset':end,'anchor_revision':revision,'anchor_state':'valid'
    });
  }

  Future<List<Map<String, Object?>>> chapterLinks(String chapterId) async =>
      (await (await db).rawQuery('''SELECT r.*, c.title FROM canon_references r JOIN canon_cards c ON c.id=r.card_id
       WHERE r.chapter_id=? ORDER BY r.created_at DESC''', [chapterId])).toList();

  Future<List<Map<String, Object?>>> characters(String universeId) async =>
      (await (await db).query('entities', where: "universe_id=? AND kind='character'", whereArgs: [universeId], orderBy: 'name COLLATE NOCASE')).toList();

  Future<void> createCharacter(String universeId, String name, String overview) async =>
      (await db).insert('entities', {'id':id(),'universe_id':universeId,'kind':'character','name':name.trim(),'overview':overview});

  Future<List<Map<String, Object?>>> search(String query) async {
    final term = '%${query.replaceAll('%','\\%').replaceAll('_','\\_')}%';
    return (await db).rawQuery('''
      SELECT 'chapter' AS kind, ch.id AS id, ch.title AS title FROM chapters ch
      JOIN writing_branches b ON b.chapter_id=ch.id AND b.is_main=1
      JOIN branch_workspaces w ON w.branch_id=b.id
      WHERE (ch.title LIKE ? ESCAPE '\\' OR w.markdown LIKE ? ESCAPE '\\')
      UNION ALL
      SELECT 'canon' AS kind, id, title FROM canon_cards WHERE title LIKE ? ESCAPE '\\' OR description LIKE ? ESCAPE '\\'
      LIMIT 60
    ''', [term,term,term,term]);
  }

  Future<Map<String, Object?>> chapterInfo(String chapterId) async {
    final rows = await (await db).rawQuery('''
      SELECT ch.id,ch.title,b.universe_id,b.id AS book_id,b.title AS book_title
      FROM chapters ch JOIN books b ON b.id=ch.book_id WHERE ch.id=?
    ''', [chapterId]);
    if(rows.isEmpty) throw StateError('Chapter not found');
    return rows.first;
  }

  Future<File> exportChapter(String chapterId, {bool plainText=false}) async {
    final draft = await mainDraft(chapterId);
    final info = await chapterInfo(chapterId);
    final content = draft['markdown'] as String;
    final text = plainText ? content.replaceAll(RegExp(r'(?<!\\)[*_`#]'), '') : content;
    final path = p.join(await getTemporaryDirectoryPath(),
        '${_safe(info['book_title'] as String)}_${_safe(info['title'] as String)}.${plainText?'txt':'md'}');
    return File(path).writeAsString(text, flush:true);
  }

  Future<String> getTemporaryDirectoryPath() async {
    // Share sheet can access files from the app cache via the share_plus FileProvider.
    return (await getTemporaryDirectory()).path;
  }

  String _safe(String value) => value.replaceAll(RegExp(r'[^a-zA-Z0-9_-]+'),'_').replaceAll(RegExp('_+'), '_');

  /// Validates a picked backup and replaces the live DB, preserving a rollback copy.
  /// Call only after user confirmation; restart app screens after successful restore.
  Future<void> restoreBackup(File selectedFile) async {
    final parent = await getDatabasesPath();
    final targetPath = p.join(parent, databaseName);
    final tempPath = p.join(parent, 'writing_studio_incoming_${id()}.db');
    final rollbackPath = p.join(parent, 'writing_studio_before_restore_${DateTime.now().millisecondsSinceEpoch}.db');
    final tempFile = File(tempPath);
    await selectedFile.copy(tempPath);
    try {
      final header = await tempFile.openRead(0, 16).fold<List<int>>(<int>[], (a,b) => a..addAll(b));
      if (ascii.decode(header, allowInvalid:true) != 'SQLite format 3\u0000') {
        throw StateError('The selected file is not a SQLite database.');
      }
      final candidate = await openDatabase(tempPath, readOnly:true, singleInstance:false);
      try {
        if(await candidate.getVersion()!=1) throw StateError('Incompatible backup schema version.');
        final check=await candidate.rawQuery('PRAGMA quick_check');
        if(check.first.values.first!='ok') throw StateError('Backup failed integrity validation.');
        final foreign=await candidate.rawQuery('PRAGMA foreign_key_check');
        if(foreign.isNotEmpty) throw StateError('Backup contains invalid references.');
        final tables=await candidate.rawQuery("SELECT name FROM sqlite_master WHERE type='table'");
        final names=tables.map((t)=>t['name']).toSet();
        if(!names.containsAll({'universes','books','chapters','branch_workspaces','writing_checkpoints'})) {
          throw StateError('Backup does not contain required Writing Studio tables.');
        }
      } finally { await candidate.close(); }
      // Make an independently verified live snapshot BEFORE attempting replacement.
      await makeRollbackBackup(rollbackPath);
      await close();
      final oldFile=File(targetPath);
      final retiredPath='$targetPath.retired';
      if (await File(retiredPath).exists()) await File(retiredPath).delete();
      if (await oldFile.exists()) await oldFile.rename(retiredPath);
      try {
        await tempFile.rename(targetPath);
      } catch (_) {
        if (await File(retiredPath).exists()) await File(retiredPath).rename(targetPath);
        rethrow;
      }
      // Keep the verified .db rollback; remove the retired live file after replacement.
      if(await File(retiredPath).exists()) await File(retiredPath).delete();
      await db;
    } finally {
      if (await tempFile.exists()) await tempFile.delete();
    }
  }

  Future<void> makeRollbackBackup(String destination) async {
    final database=await db;
    await database.execute("VACUUM INTO '${destination.replaceAll("'", "''")}'");
    final validator=await openDatabase(destination,readOnly:true,singleInstance:false);
    try {
      if((await validator.rawQuery('PRAGMA integrity_check')).first.values.first!='ok') {
        throw StateError('Cannot restore because safety backup validation failed.');
      }
    } finally { await validator.close(); }
  }

  Future<File> makeBackup() async {
    final database = await db;
    final backupPath = p.join(await getTemporaryDirectoryPath(), 'writing_studio_backup_${DateTime.now().toUtc().millisecondsSinceEpoch}.db');
    // VACUUM INTO creates a transactionally consistent standalone SQLite image.
    await database.execute("VACUUM INTO '${backupPath.replaceAll("'", "''")}'");
    final backup = File(backupPath);
    final verifier = await openDatabase(backupPath, readOnly:true, singleInstance:false);
    try {
      final integrity = await verifier.rawQuery('PRAGMA integrity_check');
      if (integrity.first.values.first != 'ok') throw StateError('Backup integrity validation failed');
      final version = await verifier.getVersion();
      if (version != 1) throw StateError('Unexpected backup version $version');
    } finally { await verifier.close(); }
    return backup;
  }
}
