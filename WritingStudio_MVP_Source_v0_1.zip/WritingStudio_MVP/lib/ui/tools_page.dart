import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';
import '../main.dart';

class ToolsPage extends ConsumerStatefulWidget {
  const ToolsPage({super.key});
  @override
  ConsumerState<ToolsPage> createState()=>_ToolsPageState();
}
class _ToolsPageState extends ConsumerState<ToolsPage> {
  bool busy=false;
  String query='';
  int searched=0;
  Future<void> backup() async {
    if(busy)return;
    setState(()=>busy=true);
    try {
      final file=await ref.read(studioProvider).makeBackup();
      await SharePlus.instance.share(ShareParams(files:[XFile(file.path)],subject:'Writing Studio full backup'));
    }catch(e){if(mounted)reportError(context,e);}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> restore() async {
    if(busy)return;
    final picked=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['db','sqlite']);
    if(picked==null||picked.files.single.path==null||!mounted)return;
    final accepted=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(
      title:const Text('Restore a backup?'),
      content:const Text('This replaces your current Writing Studio library. A safety backup will be kept in app storage. Make sure you have also exported a copy of your recent writing.'),
      actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),
        FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Restore'))],
    ));
    if(accepted!=true)return;
    setState(()=>busy=true);
    try {
      await ref.read(studioProvider).restoreBackup(File(picked.files.single.path!));
      if(mounted)await showDialog<void>(context:context,builder:(c)=>AlertDialog(
        title:const Text('Backup restored'),
        content:const Text('Close and reopen Writing Studio to refresh all screens.'),
        actions:[FilledButton(onPressed:()=>Navigator.pop(c),child:const Text('OK'))],
      ));
    }catch(e){if(mounted)reportError(context,e);}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override
  Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Tools')),
    body:ListView(padding:const EdgeInsets.all(18),children:[
      Text('Find your writing',style:Theme.of(context).textTheme.titleLarge),
      const SizedBox(height:12),TextField(onChanged:(v)=>query=v,onSubmitted:(_)=>setState(()=>searched++),
        decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:'Search chapter or canon text',
          suffixIcon:IconButton(icon:const Icon(Icons.arrow_forward),onPressed:()=>setState(()=>searched++)))),
      if(query.trim().isNotEmpty)FutureBuilder<List<Map<String,Object?>>>(key:ValueKey(searched),
        future:ref.read(studioProvider).search(query.trim()),builder:(context,s){
          if(s.hasError)return Text('Search failed: ${s.error}');
          if(!s.hasData)return const LinearProgressIndicator();
          if(s.data!.isEmpty)return const ListTile(title:Text('No matches'));
          return Column(children:[for(final result in s.data!)ListTile(
            leading:Icon(result['kind']=='canon'?Icons.layers_outlined:Icons.book_outlined),
            title:Text(result['title'] as String),subtitle:Text(result['kind'] as String),
          )]);
        }),
      const SizedBox(height:24),Text('Protect your work',style:Theme.of(context).textTheme.titleLarge),
      const SizedBox(height:8),Card(child:ListTile(
        leading:const Icon(Icons.save_alt,color:sage),
        title:const Text('Create full database backup'),
        subtitle:const Text('Export a consistent SQLite snapshot. Save it outside the app using the Android share sheet.'),
        trailing:busy?const CircularProgressIndicator():const Icon(Icons.ios_share),
        onTap:backup,
      )),
      const SizedBox(height:8),Card(child:ListTile(
        leading:const Icon(Icons.restore_outlined,color:sage),title:const Text('Restore backup'),
        subtitle:const Text('Choose a saved .db file. The app validates it and creates a safety copy before replacing your library.'),
        onTap:busy?null:restore,
      )),
      const SizedBox(height:20),
      const Text('Local-first · No sign-in · No AI API\nWriting Studio 0.1.0 — engineering source build',
        textAlign:TextAlign.center,style:TextStyle(color:sage,fontSize:12)),
    ]),
  );
}
