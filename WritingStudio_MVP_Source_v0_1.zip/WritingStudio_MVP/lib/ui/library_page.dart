import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../main.dart';
import '../data/studio_repository.dart';
import 'chapter_editor.dart';

class LibraryPage extends ConsumerStatefulWidget {
  const LibraryPage({super.key});
  @override
  ConsumerState<LibraryPage> createState()=>_LibraryPageState();
}
class _LibraryPageState extends ConsumerState<LibraryPage> {
  int refresh=0;
  Future<void> _newUniverse() async {
    final name=await askForText(context,'Name your universe',hint:'e.g. The Testing Universe');
    if(name==null) return;
    try {await ref.read(studioProvider).createUniverse(name);setState(()=>refresh++);}catch(e){if(mounted)reportError(context,e);}
  }
  @override
  Widget build(BuildContext context) {
    final repo=ref.read(studioProvider);
    return Scaffold(
      appBar:AppBar(title:const Text('Your Library'),actions:[IconButton(tooltip:'Create universe',onPressed:_newUniverse,icon:const Icon(Icons.add_circle_outline))]),
      body:FutureBuilder<List<Map<String,Object?>>>(
        key:ValueKey(refresh),future:repo.universes(),
        builder:(context,snapshot){
          if(snapshot.hasError) return Center(child:Text('Could not open library: ${snapshot.error}'));
          if(!snapshot.hasData) return const Center(child:CircularProgressIndicator());
          final items=snapshot.data!;
          if(items.isEmpty) return Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(
            mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.menu_book_outlined,size:64,color:sage),const SizedBox(height:16),
              Text('Every story begins somewhere.',style:Theme.of(context).textTheme.headlineSmall,textAlign:TextAlign.center),
              const SizedBox(height:10),const Text('Create a universe, then add Testing the Limits and Chapter 00.',textAlign:TextAlign.center),
              const SizedBox(height:24),FilledButton.icon(onPressed:_newUniverse,icon:const Icon(Icons.add),label:const Text('Create universe')),
            ])));
          return ListView(padding:const EdgeInsets.all(16),children:[
            const Text('Your fictional worlds',style:TextStyle(fontSize:14,color:sage)),const SizedBox(height:12),
            for(final u in items) Card(child:ListTile(
              contentPadding:const EdgeInsets.all(16),leading:const CircleAvatar(child:Icon(Icons.public)),
              title:Text(u['name'] as String,style:const TextStyle(fontWeight:FontWeight.w600)),
              subtitle:const Text('Open books and chapters'),trailing:const Icon(Icons.chevron_right),
              onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>UniversePage(id:u['id'] as String,title:u['name'] as String))),
            )),
          ]);
        },
      ),
      floatingActionButton:FloatingActionButton.extended(onPressed:_newUniverse,icon:const Icon(Icons.add),label:const Text('Universe')),
    );
  }
}

class UniversePage extends ConsumerStatefulWidget {
  final String id,title;
  const UniversePage({super.key,required this.id,required this.title});
  @override
  ConsumerState<UniversePage> createState()=>_UniversePageState();
}
class _UniversePageState extends ConsumerState<UniversePage> {
  int version=0;
  Future<void> create() async {
    final name=await askForText(context,'Create a book',hint:'Testing the Limits');
    if(name==null)return;
    try{await ref.read(studioProvider).createBook(widget.id,name);setState(()=>version++);}catch(e){if(mounted)reportError(context,e);}
  }
  @override
  Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(widget.title)),
    body:FutureBuilder<List<Map<String,Object?>>>(key:ValueKey(version),future:ref.read(studioProvider).books(widget.id),builder:(context,s){
      if(s.hasError)return Center(child:Text('${s.error}'));
      if(!s.hasData)return const Center(child:CircularProgressIndicator());
      if(s.data!.isEmpty)return const Center(child:Text('No books yet. Add your first one.'));
      return ListView(padding:const EdgeInsets.all(16),children:[for(final book in s.data!)Card(child:ListTile(
        leading:const Icon(Icons.book_outlined,color:sage),title:Text(book['title'] as String),
        trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>BookPage(id:book['id'] as String,title:book['title'] as String))),
      ))]);
    }),floatingActionButton:FloatingActionButton.extended(onPressed:create,icon:const Icon(Icons.add),label:const Text('Add book')),
  );
}

class BookPage extends ConsumerStatefulWidget {
  final String id,title;
  const BookPage({super.key,required this.id,required this.title});
  @override
  ConsumerState<BookPage> createState()=>_BookPageState();
}
class _BookPageState extends ConsumerState<BookPage> {
  int version=0;
  Future<void> create() async {
    final name=await askForText(context,'New chapter',hint:'Chapter 00 — Prologue');
    if(name==null)return;
    try{
      final id=await ref.read(studioProvider).createChapter(widget.id,name);
      if(!mounted)return;
      setState(()=>version++);
      await Navigator.push(context,MaterialPageRoute(builder:(_)=>ChapterEditor(chapterId:id)));
    }catch(e){if(mounted)reportError(context,e);}
  }
  @override
  Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(widget.title)),
    body:FutureBuilder<List<Map<String,Object?>>>(key:ValueKey(version),future:ref.read(studioProvider).chapters(widget.id),builder:(context,s){
      if(s.hasError)return Center(child:Text('${s.error}'));
      if(!s.hasData)return const Center(child:CircularProgressIndicator());
      if(s.data!.isEmpty)return const Center(child:Text('Your first chapter belongs here. 🌿'));
      return ListView(padding:const EdgeInsets.all(16),children:[for(final ch in s.data!)Card(child:ListTile(
        leading:const Icon(Icons.edit_note,color:sage),title:Text(ch['title'] as String),subtitle:const Text('Tap to write'),
        trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ChapterEditor(chapterId:ch['id'] as String))),
      ))]);
    }),floatingActionButton:FloatingActionButton.extended(onPressed:create,icon:const Icon(Icons.add),label:const Text('Add chapter')),
  );
}
