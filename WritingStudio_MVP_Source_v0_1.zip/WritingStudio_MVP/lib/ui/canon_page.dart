import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../main.dart';

class CanonPage extends ConsumerStatefulWidget {
  const CanonPage({super.key});
  @override
  ConsumerState<CanonPage> createState()=>_CanonPageState();
}
class _CanonPageState extends ConsumerState<CanonPage> {
  String? selectedUniverse;
  int update=0;
  Future<void> addCard() async {
    if(selectedUniverse==null)return;
    final title=await askForText(context,'Create Canon Card',hint:'What is this about?');
    if(title==null)return;
    try{await ref.read(studioProvider).createCard(selectedUniverse!,title);setState(()=>update++);}catch(e){if(mounted)reportError(context,e);}
  }
  Future<void> addCharacter() async {
    if(selectedUniverse==null)return;
    final name=await askForText(context,'Create Character',hint:'Character name');
    if(name==null)return;
    try{await ref.read(studioProvider).createCharacter(selectedUniverse!,name,'');setState(()=>update++);}catch(e){if(mounted)reportError(context,e);}
  }
  @override
  Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Canon Library')),
    body:FutureBuilder<List<Map<String,Object?>>>(future:ref.read(studioProvider).universes(),builder:(context,s){
      if(s.hasError)return Center(child:Text('${s.error}'));
      if(!s.hasData)return const Center(child:CircularProgressIndicator());
      final worlds=s.data!;
      if(worlds.isEmpty)return const Center(child:Text('Create your first universe in the Library.'));
      final id=selectedUniverse??worlds.first['id'] as String;
      return ListView(padding:const EdgeInsets.all(16),children:[
        DropdownButtonFormField<String>(initialValue:id,decoration:const InputDecoration(labelText:'Universe'),
          items:[for(final w in worlds)DropdownMenuItem<String>(value:w['id'] as String,child:Text(w['name'] as String))],
          onChanged:(v)=>setState(()=>selectedUniverse=v)),
        const SizedBox(height:20),
        Row(children:[Text('Canon Cards',style:Theme.of(context).textTheme.titleLarge),const Spacer(),
          IconButton(onPressed:(){selectedUniverse=id;addCard();},tooltip:'Add card',icon:const Icon(Icons.add_circle_outline))]),
        FutureBuilder<List<Map<String,Object?>>>(key:ValueKey('cards-$update-$id'),future:ref.read(studioProvider).canonCards(id),builder:(context,r){
          if(!r.hasData)return const LinearProgressIndicator();
          if(r.data!.isEmpty)return const Padding(padding:EdgeInsets.all(16),child:Text('No cards yet. Link a passage from the editor or create one here.'));
          return Column(children:[for(final card in r.data!)Card(child:ListTile(
            leading:const Icon(Icons.layers_outlined,color:sage),
            title:Text(card['title'] as String),
            subtitle:Text('${card['kind']} · ${card['certainty']}'),
          ))]);
        }),
        const SizedBox(height:20),
        Row(children:[Text('Characters',style:Theme.of(context).textTheme.titleLarge),const Spacer(),
          IconButton(onPressed:(){selectedUniverse=id;addCharacter();},tooltip:'Add character',icon:const Icon(Icons.person_add_alt_1))]),
        FutureBuilder<List<Map<String,Object?>>>(key:ValueKey('people-$update-$id'),future:ref.read(studioProvider).characters(id),builder:(context,r){
          if(!r.hasData)return const LinearProgressIndicator();
          if(r.data!.isEmpty)return const Padding(padding:EdgeInsets.all(16),child:Text('No characters yet. Profiles can be expanded later.'));
          return Column(children:[for(final person in r.data!)Card(child:ListTile(
            leading:const Icon(Icons.person_outline,color:sage),title:Text(person['name'] as String),
            subtitle:Text((person['overview'] as String).isEmpty?'Character overview not added yet':person['overview'] as String),
          ))]);
        }),
      ]);
    }),
  );
}
