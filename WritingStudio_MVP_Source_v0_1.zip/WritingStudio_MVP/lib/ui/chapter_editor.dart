import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_markdown_plus/flutter_markdown_plus.dart';
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';
import '../main.dart';
import '../data/studio_repository.dart';

class ChapterEditor extends ConsumerStatefulWidget {
  final String chapterId;
  const ChapterEditor({super.key,required this.chapterId});
  @override
  ConsumerState<ChapterEditor> createState()=>_ChapterEditorState();
}

class _ChapterEditorState extends ConsumerState<ChapterEditor> with WidgetsBindingObserver {
  final editor=TextEditingController();
  final focusNode=FocusNode();
  Timer? timer;
  String title='Chapter Editor',universeId='',branchId='',savedText='',saveStatus='Opening...';
  int revision=0;
  bool ready=false,readMode=false,focusMode=false,allowExit=false,saveFailure=false;
  double fontSize=18;
  Future<void>? activeSave;

  StudioRepository get repo=>ref.read(studioProvider);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_load());
  }

  Future<void> _load() async {
    try {
      final info=await repo.chapterInfo(widget.chapterId);
      final draft=await repo.mainDraft(widget.chapterId);
      if(!mounted)return;
      title=info['title'] as String;
      universeId=info['universe_id'] as String;
      branchId=draft['branch_id'] as String;
      revision=draft['revision'] as int;
      savedText=draft['markdown'] as String;
      editor.text=savedText;
      editor.addListener(_changed);
      setState((){ready=true;saveStatus='Saved';});
    }catch(e){if(mounted)setState(()=>saveStatus='Error opening chapter: $e');}
  }

  void _changed() {
    if(!ready)return;
    timer?.cancel();
    final dirty=editor.text!=savedText;
    setState(()=>saveStatus=dirty?'Unsaved changes':'Saved');
    if(dirty)timer=Timer(const Duration(milliseconds:650),()=>unawaited(_flush()));
  }

  // All overlapping flush requests serialize through activeSave.
  Future<void> _flush() async {
    if(!ready||saveFailure)return;
    timer?.cancel();
    if(activeSave!=null) {
      try { await activeSave; } catch (_) { return; }
      if(saveFailure) return;
      if(editor.text!=savedText) return _flush();
      return;
    }
    if(editor.text==savedText)return;
    final snapshot=editor.text;
    final expected=revision;
    Future<void> oneSave() async {
      final newVersion=await repo.saveDraft(branchId,expected,snapshot);
      revision=newVersion;
      savedText=snapshot;
    }
    final pending=oneSave();
    activeSave=pending;
    try {
      await pending;
      if(mounted)setState(()=>saveStatus=editor.text==savedText?'Saved':'Saving newest changes...');
    }catch(e){
      saveFailure=true;
      if(mounted){setState(()=>saveStatus='Save failed — text kept in editor');reportError(context,e);}
      return;
    }finally{activeSave=null;}
    if(editor.text!=savedText)await _flush();
  }

  Future<bool> _saveSafe() async {
    await _flush();
    return !saveFailure && editor.text==savedText;
  }

  Future<void> _exit() async {
    FocusScope.of(context).unfocus();
    if(!await _saveSafe()) {
      if(mounted)reportError(context,'Writing was not saved. Stay here and use Retry save.');
      return;
    }
    if(!mounted)return;
    setState(()=>allowExit=true);
    Navigator.of(context).pop();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if(state==AppLifecycleState.inactive||state==AppLifecycleState.paused||state==AppLifecycleState.detached) {
      unawaited(_flush());
    }
  }

  void _wrapSelection(String before,String after) {
    final selection=editor.selection;
    final value=editor.text;
    final a=selection.isValid?selection.start: value.length;
    final b=selection.isValid?selection.end: value.length;
    final start=a<0?value.length:a, end=b<0?value.length:b;
    final selectionText=value.substring(start,end);
    final text='$before$selectionText$after';
    editor.value=TextEditingValue(
      text:value.replaceRange(start,end,text),
      selection:TextSelection(baseOffset:start+before.length,extentOffset:start+before.length+selectionText.length),
    );
    focusNode.requestFocus();
  }

  Future<void> _checkpoint() async {
    if(!await _saveSafe()){if(mounted)reportError(context,'Save text before creating a checkpoint.');return;}
    if(!mounted)return;
    final name=await askForText(context,'Name this checkpoint',hint:'Prologue first pass');
    if(name==null)return;
    try {await repo.createCheckpoint(widget.chapterId,branchId,name);if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Checkpoint created')));}
    catch(e){if(mounted)reportError(context,e);}
  }

  Future<void> _checkpointHistory() async {
    if(!await _saveSafe())return;
    final items=await repo.checkpoints(branchId);
    if(!mounted)return;
    await showModalBottomSheet<void>(context:context,isScrollControlled:true,showDragHandle:true,builder:(sheetContext)=>SafeArea(child:
      Padding(padding:const EdgeInsets.all(16),child:Column(mainAxisSize:MainAxisSize.min,children:[
        Text('Checkpoint history',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:12),
        if(items.isEmpty)const Padding(padding:EdgeInsets.all(24),child:Text('No checkpoints yet.')),
        ...items.take(20).map((cp)=>ListTile(
          title:Text(cp['title'] as String),subtitle:Text('${cp['kind']} · ${cp['created_at']}'),
          trailing:const Icon(Icons.compare_arrows),
          onTap:() async {
            Navigator.pop(sheetContext);
            if(!mounted)return;
            await _compare(cp);
          },
        )),
      ]))));
  }

  Future<void> _compare(Map<String,Object?> cp) async {
    final old=cp['markdown'] as String;
    final countOld=old.runes.length, countNew=editor.text.runes.length;
    await showDialog<void>(context:context,builder:(dialogContext)=>AlertDialog(
      title:Text('Compare: ${cp['title']}'),
      content:SizedBox(width:500,child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Text('Checkpoint ($countOld characters)',style:const TextStyle(fontWeight:FontWeight.w600)),
        SelectableText(old.isEmpty?'(empty)':old),const Divider(height:28),
        Text('Current ($countNew characters)',style:const TextStyle(fontWeight:FontWeight.w600)),
        SelectableText(editor.text.isEmpty?'(empty)':editor.text),
      ]))),
      actions:[TextButton(onPressed:()=>Navigator.pop(dialogContext),child:const Text('Close')),
        TextButton(onPressed:() async {
          Navigator.pop(dialogContext);
          if(!mounted)return;
          final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(
            title:const Text('Restore this version?'),
            content:const Text('A safety checkpoint of the current draft will be created first.'),
            actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),
              FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Restore')),
            ],
          ));
          if(yes!=true)return;
          try {
            await repo.restoreCheckpoint(cp['id'] as String);
            final draft=await repo.mainDraft(widget.chapterId);
            savedText=draft['markdown'] as String;
            revision=draft['revision'] as int;
            editor.text=savedText;
            if(mounted)setState(()=>saveStatus='Restored and saved');
          }catch(e){if(mounted)reportError(context,e);}
        },child:const Text('Restore')),
      ],
    ));
  }

  Future<void> _canonAction() async {
    final selected=editor.selection;
    final raw=editor.text;
    if(!selected.isValid||selected.isCollapsed||selected.start<0||selected.end>raw.length){
      reportError(context,'Highlight a passage first, then tap Link Canon.');return;
    }
    final start=selected.start,end=selected.end;
    if(!await _saveSafe())return;
    if(!mounted)return;
    if(editor.text!=raw){reportError(context,'Text changed; select the passage again.');return;}
    final cards=await repo.canonCards(universeId);
    if(!mounted)return;
    String role='Character perspective';
    final selectedCard=await showModalBottomSheet<String>(
      context:context,isScrollControlled:true,showDragHandle:true,
      builder:(c)=>SafeArea(child:Padding(
        padding:EdgeInsets.fromLTRB(16,8,16,MediaQuery.of(c).viewInsets.bottom+20),
        child:StatefulBuilder(builder:(c,rebuild)=>Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('Link selected passage',style:TextStyle(fontWeight:FontWeight.bold,fontSize:20)),
          const SizedBox(height:8),Text('“${raw.substring(start,end)}”',maxLines:3,overflow:TextOverflow.ellipsis),
          const SizedBox(height:12),DropdownButtonFormField<String>(initialValue:role,decoration:const InputDecoration(labelText:'Reference type'),
            items:const ['Character perspective','Fact evidence','Foreshadowing','Revelation','Contradiction','Motif appearance','Editorial reference']
                .map((r)=>DropdownMenuItem(value:r,child:Text(r))).toList(),onChanged:(v){if(v!=null)rebuild(()=>role=v);}),
          const SizedBox(height:12),ConstrainedBox(constraints:const BoxConstraints(maxHeight:220),child:ListView(shrinkWrap:true,children:[
            for(final card in cards)ListTile(leading:const Icon(Icons.layers_outlined),title:Text(card['title'] as String),onTap:()=>Navigator.pop(c,card['id'] as String)),
          ])),
          FilledButton.tonalIcon(onPressed:()=>Navigator.pop(c,'__new__'),icon:const Icon(Icons.add),label:const Text('Create new card')),
        ])),
      )),
    );
    if(selectedCard==null||!mounted)return;
    String cardId=selectedCard;
    try {
      if(selectedCard=='__new__') {
        final title=await askForText(context,'New Canon Card',hint:'A secret, impression, fact...');
        if(title==null)return;
        cardId=await repo.createCard(universeId,title);
      }
      await repo.linkSelection(cardId:cardId,chapterId:widget.chapterId,branchId:branchId,revision:revision,
        markdown:editor.text,start:start,end:end,role:role);
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Canon Card linked')));
    }catch(e){if(mounted)reportError(context,e);}
  }

  Future<void> _showLinks() async {
    final refs=await repo.chapterLinks(widget.chapterId);
    if(!mounted)return;
    await showModalBottomSheet<void>(context:context,showDragHandle:true,isScrollControlled:true,builder:(c)=>SafeArea(child:Padding(padding:const EdgeInsets.all(18),
      child:Column(mainAxisSize:MainAxisSize.min,children:[
        const Text('Chapter Canon Links',style:TextStyle(fontWeight:FontWeight.bold,fontSize:20)),
        if(refs.isEmpty)const Padding(padding:EdgeInsets.all(20),child:Text('No linked passages yet.')),
        ConstrainedBox(constraints:const BoxConstraints(maxHeight:450),child:ListView(shrinkWrap:true,children:[
          for(final refLink in refs)ListTile(title:Text(refLink['title'] as String),subtitle:Text('${refLink['role']} · ${refLink['anchor_state']}\n“${refLink['excerpt']}”',maxLines:3)),
        ])),
      ]))));
  }

  Future<void> _export(bool plain) async {
    if(!await _saveSafe())return;
    try {
      final file=await repo.exportChapter(widget.chapterId,plainText:plain);
      await SharePlus.instance.share(ShareParams(files:[XFile(file.path)],subject:'Writing Studio chapter export'));
    }catch(e){if(mounted)reportError(context,e);}
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    timer?.cancel();
    editor.dispose();focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if(!ready) return Scaffold(appBar:AppBar(title:const Text('Chapter Editor')),body:Center(child:Text(saveStatus)));
    return PopScope(
      canPop:allowExit,
      onPopInvokedWithResult:(didPop,result){if(!didPop)unawaited(_exit());},
      child:Scaffold(
        appBar:AppBar(
          leading:IconButton(icon:const Icon(Icons.arrow_back),tooltip:'Save and leave',onPressed:_exit),
          title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w600)),
            Text(saveStatus,style:TextStyle(fontSize:11,color:saveFailure?Colors.red:sage))]),
          actions:[
            if(saveFailure)IconButton(tooltip:'Retry save',onPressed:(){saveFailure=false;unawaited(_flush());},icon:const Icon(Icons.refresh)),
            IconButton(tooltip:'Read mode',icon:Icon(readMode?Icons.edit:Icons.chrome_reader_mode_outlined),onPressed:()=>setState(()=>readMode=!readMode)),
            PopupMenuButton<String>(onSelected:(v){
              if(v=='focus')setState(()=>focusMode=!focusMode);
              if(v=='checkpoint')unawaited(_checkpoint());
              if(v=='history')unawaited(_checkpointHistory());
              if(v=='links')unawaited(_showLinks());
              if(v=='markdown')unawaited(_export(false));
              if(v=='text')unawaited(_export(true));
            },itemBuilder:(_)=>[
              PopupMenuItem(value:'focus',child:Text(focusMode?'Exit focus mode':'Focus mode')),
              const PopupMenuItem(value:'checkpoint',child:Text('New checkpoint')),
              const PopupMenuItem(value:'history',child:Text('Checkpoints & compare')),
              const PopupMenuItem(value:'links',child:Text('Canon links')),
              const PopupMenuItem(value:'markdown',child:Text('Export Markdown')),
              const PopupMenuItem(value:'text',child:Text('Export plain text')),
            ]),
          ],
        ),
        body:Column(children:[
          if(!readMode&&!focusMode)Container(
            color:Colors.white,
            child:SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:[
              IconButton(tooltip:'Bold',onPressed:()=>_wrapSelection('**','**'),icon:const Icon(Icons.format_bold)),
              IconButton(tooltip:'Italic',onPressed:()=>_wrapSelection('*','*'),icon:const Icon(Icons.format_italic)),
              IconButton(tooltip:'Scene break',onPressed:()=>_wrapSelection('\n\n---\n\n',''),icon:const Icon(Icons.horizontal_rule)),
              TextButton.icon(onPressed:_canonAction,icon:const Icon(Icons.link),label:const Text('Canon')),
              IconButton(tooltip:'Smaller text',onPressed:()=>setState(()=>fontSize=(fontSize-1).clamp(14,28).toDouble()),icon:const Icon(Icons.text_decrease)),
              IconButton(tooltip:'Larger text',onPressed:()=>setState(()=>fontSize=(fontSize+1).clamp(14,28).toDouble()),icon:const Icon(Icons.text_increase)),
            ])),
          ),
          Expanded(child:readMode
            ? SingleChildScrollView(padding:const EdgeInsets.all(24),child:MarkdownBody(data:editor.text.isEmpty?'*This chapter is empty.*':editor.text))
            : Padding(padding:const EdgeInsets.symmetric(horizontal:20,vertical:12),child:TextField(
                controller:editor,focusNode:focusNode,expands:true,maxLines:null,minLines:null,
                keyboardType:TextInputType.multiline,textCapitalization:TextCapitalization.sentences,
                style:TextStyle(fontSize:fontSize,height:1.65,color:const Color(0xFF2E342E)),
                decoration:const InputDecoration(border:InputBorder.none,hintText:'Your story begins here...',hintStyle:TextStyle(color:Colors.black38)),
              )),
          ),
          if(!focusMode)SafeArea(top:false,child:Container(
            padding:const EdgeInsets.symmetric(horizontal:16,vertical:8),
            color:Colors.white,
            child:Row(children:[const Icon(Icons.auto_stories_outlined,size:16,color:sage),const SizedBox(width:7),
              Text('${editor.text.trim().isEmpty?0:editor.text.trim().split(RegExp(r'\s+')).length} words',style:const TextStyle(color:sage,fontSize:12)),
              const Spacer(),TextButton.icon(onPressed:_showLinks,icon:const Icon(Icons.link,size:16),label:const Text('References')),
            ]),
          )),
        ]),
      ),
    );
  }
}
